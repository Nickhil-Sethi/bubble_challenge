input_data = {
	"groups" : 3,
	"students" : [
        {"name": "Ava", "noisy": True, "understands": True, "fights_with": ["Noah", "Madison", "Gavin"]},
        {"name": "Madison", "noisy": False, "understands": False, "fights_with": ["Olivia", "Kaylee"]},
        {"name": "Daniel", "noisy": True, "understands": True, "fights_with": []},      
        {"name": "Olivia", "noisy": False, "understands": False, "fights_with": ["Mia"]},      
        {"name": "Noah", "noisy": False, "understands": True, "fights_with": ["Kaylee"]},      
        {"name": "Mia", "noisy": True, "understands": False, "fights_with": []},
        {"name": "Jayden", "noisy": False, "understands": False, "fights_with": ["Mia", "Gavin", "Kaylee"]},
        {"name": "Brianna", "noisy": True, "understands": True, "fights_with": []},     
        {"name": "Gavin", "noisy": False, "understands": False, "fights_with": ["Noah"]},      
        {"name": "Kaylee", "noisy": True, "understands": False, "fights_with": []}
    ]
}

if __name__=='__main__':
	print data