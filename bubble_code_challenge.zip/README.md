# Bubble Code Challenge

Hi, thanks for taking a look at my code challenge! I took a naive brute force approach to solving the problem, first generating all possible configurations, and then checking every configuration, and finally returning the solution with the most uniform group size.

To run, install python 2.7, modify the dictionary in config.py to contain whatever input data you would like (this could later be modified to read a proper json object from a text file, but is easier to modify for testing), then enter 'python group_students.py' in to the commandline in the /bubble directory.